"""Standart docstring"""

